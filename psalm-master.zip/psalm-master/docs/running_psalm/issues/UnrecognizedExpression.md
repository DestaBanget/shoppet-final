# UnrecognizedExpression

Emitted when Psalm encounters an expression that it doesn't know how to handle. This should never happen.
