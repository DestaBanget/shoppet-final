# NullFunctionCall

Emitted when trying to use `null` as a `callable`

```php
<?php

$arr = null;
echo $arr();
```
