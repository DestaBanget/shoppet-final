# ComplexFunction

Emitted when a function is too complicated. Complicated functions should be split up.
