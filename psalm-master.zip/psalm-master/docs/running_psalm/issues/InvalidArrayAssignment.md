# InvalidArrayAssignment

Emitted when attempting to assign a value on a non-array

```php
<?php

$arr = 5;
$arr[0] = 3;
```
