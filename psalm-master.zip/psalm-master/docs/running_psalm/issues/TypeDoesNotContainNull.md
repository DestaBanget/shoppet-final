# TypeDoesNotContainNull

Emitted when checking a non-nullable type for `null`

```php
<?php

$a = "hello";
if ($a === null) {}
```
