# NullReference

Emitted when attempting to call a method on `null`

```php
<?php

$a = null;
$a->foo();
```
