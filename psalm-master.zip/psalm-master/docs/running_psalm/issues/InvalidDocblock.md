# InvalidDocblock

Emitted when there's an error in a docblock type

```php
<?php

/** @var array() */
$a = [];
```
