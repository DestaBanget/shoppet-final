# PossiblyNullArrayAssignment

Emitted when trying to set a value on a possibly null array

```php
<?php

$a = null;
$a[0][] = 1;
```
