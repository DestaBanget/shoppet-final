# TaintedInput

Emitted when tainted input detection is turned on
