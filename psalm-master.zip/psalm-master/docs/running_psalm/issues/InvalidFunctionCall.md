# InvalidFunctionCall

Emitted when calling a function on a non-callable variable

```php
<?php

$a = 5;
$b = $a();
```
