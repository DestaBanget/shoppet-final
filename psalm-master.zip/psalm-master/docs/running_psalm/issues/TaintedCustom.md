# TaintedCustom

Emitted when tainted input detection is turned on and custom-tainted data is detected.
