# PluginIssue

Can be emitted by plugins.
