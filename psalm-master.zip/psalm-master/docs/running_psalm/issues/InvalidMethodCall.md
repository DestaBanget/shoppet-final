# InvalidMethodCall

Emitted when attempting to call a method on a non-object

```php
<?php

$a = 5;
$a->foo();
```
