# MissingFile

Emitted when using `include` or `require` on a file that does not exist

```php
<?php

require("nonexistent.php");
```
