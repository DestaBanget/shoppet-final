# EmptyArrayAccess

Emitted when attempting to access a value on an empty array

```php
<?php

$a = [];
$b = $a[0];
```
