# UndefinedTrace

Attempt to trace an undefined variable

```php
<?php

/** @psalm-trace $x */
echo 'Hello World!';
```

## How to fix

Provide existing variable or remove it
