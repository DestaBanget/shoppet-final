<?php

declare(strict_types=1);

namespace Psalm\Exception;

final class ConfigNotFoundException extends ConfigException
{
}
