<?php

declare(strict_types=1);

namespace Psalm\Exception;

use Exception;

final class UnsupportedIssueToFixException extends Exception
{

}
